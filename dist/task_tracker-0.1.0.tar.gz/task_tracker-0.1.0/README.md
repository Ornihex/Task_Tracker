It's just another cli task tracker
